package com.example.nameless.posterappshit;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Date;
import java.util.List;
import java.util.Vector;

public class HomeActivity extends AppCompatActivity {
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference usersReference, anonimousPostReference, publicPostRef;
    LinearLayout layoutprincipal ;
    FrameLayout frameLayout ;
    public  TextView capturador;
    public static UserAdapter userAdapter;
    private LinearLayout feedLayout;

    @SuppressLint({"ResourceAsColor", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Toolbar config

        layoutprincipal = (LinearLayout) findViewById(R.id.layoutPrincipal);
        setContentView(R.layout.activity_home);
        android.support.v7.widget.Toolbar toolbar =(android.support.v7.widget.Toolbar) findViewById(R.id.toolBarFeed);
        toolbar.setTitle(" FAJ FAJ");
        //toolbar.setTitleTextColor(R.color.colorT);

        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
            toolbar.setElevation(10f);
            toolbar.setFocusable(true);
        }
        toolbar.inflateMenu(R.menu.menu_toolbar_config);
        // Framelayout


        // codigo para linkar

        //Adapter e RVIew
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycler);
        final MeuAdapter meuAdapter = new MeuAdapter(this);
        recyclerView.setAdapter(meuAdapter);

        //Layout Manager e RVIew

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        recyclerView.setItemAnimator(new DefaultItemAnimator());


        // codigo para linkar Post

        //Adapter e RVIew
        RecyclerView recycleFeed = (RecyclerView) findViewById(R.id.recycleFeed);
        final PostNewAdapter postNewAdapter = new PostNewAdapter(this);
        recycleFeed.setAdapter(postNewAdapter);

        //Layout Manager e RVIew

        LinearLayoutManager linearLayoutManagerFeed = new LinearLayoutManager(this);
        linearLayoutManagerFeed.setOrientation(LinearLayoutManager.VERTICAL);
        recycleFeed.setLayoutManager(linearLayoutManagerFeed);

        recycleFeed.setItemAnimator(new DefaultItemAnimator());




        TabHost tabHost = (TabHost) findViewById(R.id.tabHost);
        tabHost.setup();

        TabHost.TabSpec aba1 = tabHost.newTabSpec("PRIMEIRA");
        aba1.setContent(R.id.feeding_area);
        aba1.setIndicator("FEED NOTICIAS");


        TabHost.TabSpec aba2 = tabHost.newTabSpec("SEGUNDA");
        aba2.setContent(R.id.SEGUNDA);
        aba2.setIndicator("MEUS CONTACTOS");

        tabHost.addTab(aba1);
        tabHost.addTab(aba2);


        usersReference = firebaseDatabase.getReference(BDCaminhos.USER);
        anonimousPostReference = firebaseDatabase.getReference(BDCaminhos.POSTS_ANONIMOS);

        //listContacts = findViewById(R.id.list_view_contact);

        //userAdapter = new UserAdapter(getLayoutInflater());
        //listContacts.setAdapter(userAdapter);
      //  feedLayout = findViewById(R.id.feeding_area);

        anonimousPostReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    Post post = data.getValue(Post.class);

                 meteNoSQL(post);


                    if (!postNewAdapter.getList().contains(post)) {
                        postNewAdapter.add(post);
                    } else {
                        //listaUsuarios.update(value);
                    }
                    //capturador = new TextView(HomeActivity.this);
                    //capturador.setText("De: "+post.getSender()+"\n Mensagem:    " + post.getText().toString() + "\n Data:   " + new Date(post.getDate()).toString());
                  //  feedLayout.addView(capturador);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        usersReference.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                for (DataSnapshot data : dataSnapshot.getChildren()) {
                    User value = data.getValue(User.class);

                    Log.d("Initial DB Reading", "Value of key is: " + dataSnapshot.getChildren());
                    Log.d("Initial DB Reading", "Value of capturador is: " + value);
                    if (!meuAdapter.getList().contains(value)) {
                        meuAdapter.add(value);
                    } else {
                        //listaUsuarios.update(value);
                    }

                    Log.d("Initial DB Reading", "Map value creation :" + meuAdapter.getList());
                }


            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("Initial DB Reading", "Failed to read value.", error.toException());
            }
        });


    }

    private void meteNoSQL(Post post) {
        /**
         *
         *
         *
         *
         *
         *
         *
         *
         *
         *
         *
         *
         *
         *
         *
         *
         *
         * */
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    public void verificarPerfil(MenuItem item) {

        Toast.makeText(HomeActivity.this, "Estou chateado", Toast.LENGTH_SHORT).show();
    }
    public void verificarSettings(MenuItem item) {
        Toast.makeText(HomeActivity.this,"Comming soon",Toast.LENGTH_LONG).show();
    }
    public void verificarUs(MenuItem item) {
        Toast.makeText(HomeActivity.this,"Comming soon",Toast.LENGTH_LONG).show();
    }
    public void verificarLogout(MenuItem item) {
        Toast.makeText(HomeActivity.this,"Comming soon",Toast.LENGTH_LONG).show();
    }



    public void postarMensagem(View view) {



        final AlertDialog.Builder alertBuilder = new AlertDialog.Builder(HomeActivity.this);
        alertBuilder.setTitle("Postar Mensagem");

        View customView = getLayoutInflater().inflate(R.layout.dialog_layout, null, false);
        ImageButton accept = customView.findViewById(R.id.accept_dialog_btn);
        ImageButton acessoGaleria = customView.findViewById(R.id.acessoGaleria);
        ImageButton acessoCamera = customView.findViewById(R.id.acessoCamera);
        //ListView listDialogContact = customView.findViewById(R.id.list_view_contacts_dialog);
        final EditText text = customView.findViewById(R.id.input_text_dialog_post);


        //listDialogContact.setAdapter(userAdapter);

        alertBuilder.setView(customView);
        final AlertDialog alertDialog = alertBuilder.create();
        alertDialog.show();

        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Post post = new Post();
                post.setDate(System.currentTimeMillis());
                post.setSender(getString(R.string.usuarioAnonimo));
                // post.setSender(LoginActivity.firebaseUser.getDisplayName());
                post.setText(text.getEditableText().toString());

                anonimousPostReference.child(new Date(post.getDate()).toString()).setValue(post);

                alertDialog.hide();
                text.setText("");
            }
        });


        acessoCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(HomeActivity.this, "Camera", Toast.LENGTH_SHORT).show();
            }
        });

        acessoGaleria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(HomeActivity.this, "Galeria", Toast.LENGTH_SHORT).show();
            }
        });


    }
}
