package com.example.nameless.posterappshit;

/**
 * Created by SUtui on 5/7/2018.
 */

public class BDCaminhos {
    public static final String USER = "USUARIOS";
    public static final String POSTS_ANONIMOS = "POSTS_ANONIMOS";
    public static final String POSTS_PRIVADOS = "POSTS_PRIVADOS";
    public static final String POSTS_PUBLICOS = "POSTS_PUBLICOS";
    public static final String COMMENTS = "COMENTARIOS";
}
